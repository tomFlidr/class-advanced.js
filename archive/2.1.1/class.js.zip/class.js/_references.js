/// <autosync enabled="true" />
/// <reference path="builds/latest/class.dev.js" />