/// <autosync enabled="true" />
/// <reference path="builds/latest/class.src.js" />